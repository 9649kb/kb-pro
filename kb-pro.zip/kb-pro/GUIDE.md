# 📱 KB PRO – GUIDE DE DÉPLOIEMENT

## Fichiers à uploader sur GitHub

- index.html
- manifest.json
- sw.js
- icon-192.png
- icon-512.png

---

## ÉTAPE 1 – Uploader sur GitHub

1. Va sur github.com/9649kb/kb-pro
2. Clique "Add file" → "Upload files"
3. Glisse tous les fichiers ci-dessus
4. Clique "Commit changes"

---

## ÉTAPE 2 – Déployer sur Netlify

1. Va sur app.netlify.com
2. Clique "Add new site" → "Import an existing project"
3. Choisis "GitHub"
4. Sélectionne le dépôt "kb-pro"
5. Clique "Deploy site"
6. Attends 1 minute → ton lien est prêt !

---

## ÉTAPE 3 – Activer les règles Firebase

1. Va sur firebase.google.com → ton projet KB-Pro
2. Clique "Firestore Database" → "Règles"
3. Colle le contenu du fichier firebase-rules.txt
4. Clique "Publier"

---

## ÉTAPE 4 – Créer le preset Cloudinary

1. Va sur cloudinary.com → Settings → Upload
2. Clique "Add upload preset"
3. Nom : kb_pro_unsigned
4. Signing mode : Unsigned
5. Sauvegarde

---

## CONNEXION

- 👑 Patron : mot de passe → KB2026patron
- 👤 Agent : nom + code (à créer depuis l'espace Patron)

---

## INSTALLER L'APP SUR TÉLÉPHONE

1. Ouvre le lien Netlify dans Chrome
2. Clique les 3 points en haut à droite
3. Clique "Ajouter à l'écran d'accueil"
4. L'app apparaît comme une vraie application !
